package cs2110.assignment4.kmd226yad4;
/**
 * DO NOT MODIFY THIS CLASS IN ANY WAY.
 * 
 * An enumeration of all available tools.
 */
public enum Tool {
	PENCIL, ERASER, COLOR_PICKER, AIRBRUSH, LINE, CIRCLE
}
