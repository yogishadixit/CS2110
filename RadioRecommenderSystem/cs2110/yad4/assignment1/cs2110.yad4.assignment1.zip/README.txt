Name: Yogisha Dixit

NetID: yad4

Issues:

Even though I checked, double checked, debugged (using the debugging tool) and tested (using a small subset of songs, stations and play log) my songSimilarity, stationSimilarity and makeRecommendation methods, for some reason they still do not return the expected output. For instance similarsong <101> is supposed to output 19. The Beatles - Get Back, my program outputs 140. Pink Floyd - Speak To Me\/Breathe. When I created my own songs_test.txt, stations_test.txt, and playlog_test.txt and checked the expected values against the output values, they all were correct! At this point, I really have no idea where the error could be.

Consulted with:
Brian Finn (consultant)
Sara Boccabella (consultant)
Ray Weng
