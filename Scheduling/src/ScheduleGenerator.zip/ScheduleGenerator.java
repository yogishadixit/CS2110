//Don't import anything else.

import java.util.Arrays; // you can only use toString & sort

/**
 *
 * The purpose of this class is to compute an optimal schedule for the
 * execution of tasks on identical processors.
 *
 */
public class ScheduleGenerator {
	private int[] tasks;
	private int m;
	private Schedule best;
	/**
	 * If the arguments are not valid, throw an IllegalArgumentException.
	 * 
	 * @param tasks Duration of each task. 
	 * @param m Number of processors.
	 */
	public ScheduleGenerator(int[] tasks, int m) 
	{
		this.tasks = tasks;
		this.m = m;
	}
	
	/**
	 * Since the classical scheduling problem is hard to compute
	 * (it seems to require unavoidably super-polynomial time, because it is NP-complete)
	 * we ask you to implement a suboptimal fast heuristic algorithm.
	 * 
	 * Greedy heuristic:
	 * Schedule the tasks one by one, assigning at every stage a task to a
	 * processor that has minimum load (total processing to do).
	 * 
	 * @return The schedule given by a suboptimal heuristic algorithm.
	 */
	public Schedule heuristicScheduling() 
	{ 
		ScheduledTask[] heuristic = new ScheduledTask[tasks.length];
		try
		{
			// this is the counter that keeps track of how many tasks have been assigned
			int counter = 0;
			// this is an array of the combined duration of all the tasks on each of the processors
			int[] processorTasks = new int[m];
			while (counter < tasks.length)
			{
				// this is an index of where the processor with the minimum duration of tasks is in the 
				// processorTasks array
				int processorWithMinDuration = 0;
				// this finds the index of the processor with the minimum duration 
				for (int i = 0; i < m; i++)
				{
					if (processorTasks[i] < processorTasks[processorWithMinDuration])
					{
						processorWithMinDuration = i;
					}
				}
				// this assigns the processor with the minimum duration the task
				heuristic[counter] = new ScheduledTask(counter, processorWithMinDuration);
			
				// this updates the duration of the processor to which the task was most recently assigned.
				processorTasks[processorWithMinDuration] += tasks[counter];
				counter++;
			}
		}
		catch (Throwable e) 
		{ 
			System.out.println("Oops! Something went wrong. Please check the stack trace to determine the error.");
			e.printStackTrace(); 
		}
		Schedule temp = new Schedule(tasks, m, heuristic);
		return temp;
	}
	
	/**
	 * Find an optimal schedule, that is one with minimum makespan.
	 */
	public Schedule getOptSchedule() 
	{
		ScheduledTask[] schedule = new ScheduledTask[tasks.length];
		best = recursive(schedule, 0);
		return best;
	}
	 
	/**
	 * This method takes an initially empty array of scheduled tasks and starts filling them one by one. A task 
	 * gets assigned to each of the processors. Once a task is assigned, the method recursively calls itself 
	 * so that the next task can be assigned. Once all the tasks have been assigned, the method returns and 
	 * the makespan is checked. So basically, the method checks each permutation of the tasks assigned 
	 * to the processors.
	 * @param schedule the array containing all the tasks that have already been assigned to processors
	 * @param startIndex the index of the first task in the tasks array that has yet to be assigned. it gets 
	 * incremented with each recursive call to this method
	 * @return the schedule with the smallest makespan that can be created
	 */
	public Schedule recursive(ScheduledTask[] schedule, int startIndex)
	{
		// I still have to clone ScheduledTask[] each time so that it doesn't get overwritten each time
		// the recursive method is called.
		
		// this is the base case. if the start index is at the size of schedule, aka all the tasks have
		// been assigned, then the method returns the complete schedule formed.
		if (startIndex == schedule.length)
		{
			return new Schedule(tasks, m, schedule);
		}
		for (int i = 0; i < m; i++)
		{
			schedule[startIndex] = new ScheduledTask(startIndex, i);
			Schedule temp = recursive(schedule, startIndex + 1);
			System.out.println(temp);
			if (startIndex == 0 && i == 0)
			{
				best = temp;
			}
			int tempMakeSpan = 0;
			if(temp != null){
				tempMakeSpan = temp.getMakespan();
			}
			int bestMakeSpan = 0;
			if(best != null)
			{
				bestMakeSpan = best.getMakespan();
			}
			if (tempMakeSpan < bestMakeSpan)
			{
				best = temp;
			}
		}
		return best;
	}
	/**
	 * NOTE: You do NOT have to use this class if you don't want to or
	 * you can't see why it's useful.
	 * 
	 * The purpose of this class is to provide a basic implementation of a "mutable integer". 
	 */
	class MyInt {
		public int v;
		public MyInt(int v) { this.v = v; }
		public String toString() { return Integer.toString(v); }
	}
	
}
