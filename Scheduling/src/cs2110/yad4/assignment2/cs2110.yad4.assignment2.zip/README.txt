Name: Yogisha Dixit
NetID: yad4

I do not know of any issues with my code. 

I would like to clarify the part of my recursive method that limits the number of schedules it looks at. I have a global variable "best" which records the best schedule (or the schedule with the smallest makespan) found so far. If the method finds another schedule with a smaller makespan, it will replace the best with this new schedule and keep looking. I have initialized by best schedule to the heuristicSchedule because I am making the assumption that the optimal schedule would have to be either equal to or better than the scheudle found heuristically. 

I consulted with:
-- Akilesh Potti (TA)